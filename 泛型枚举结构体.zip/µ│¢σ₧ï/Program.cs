﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Apple apple = new Apple() { Color = "Red" };
            Book book = new Book() {
                Name = "<<Harry Potter>>",
                MyProperty = 23445,
            };
            Box<Apple> box1 = new Box<Apple>() { Cargo = apple };
            Box<Book> box2 = new Box<Book>() { Cargo = book };
            Console.WriteLine(box1.Cargo.Color);
            Console.WriteLine(box2.Cargo.MyProperty);
        }
    }
    class Apple
    {
        public string Color { get; set; }
        
    }
    class Book
    {
        public string Name { get; set; }
        public int MyProperty { get; set; }
    }
    class Box<TCargo>
    {
        public TCargo Cargo { get; set; }
    }
}



