﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace 泛型例子3
{
    class Program
    {
        static void Main(string[] args)
        {
            IList<int> list = new List<int>();
            for (int i = 0; i < 100; i++)
            {
                list.Add((int)Math.Pow(i,2));
            }
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            
        }
        
    }
}
