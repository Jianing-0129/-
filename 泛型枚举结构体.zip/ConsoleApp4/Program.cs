﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Student<int> student = new Student<int>()
            {

                Name = "fgf",
                ID = 23452345
            };
            Console.WriteLine(student.Name);
            Console.WriteLine();
        }
        interface Iunique<TID>
        {
            TID ID { get; set; }
        }
        class Student<TID> : Iunique<TID>
        {
            public TID ID { get; set; }
            public String Name { get; set; }

        }
    }
}
