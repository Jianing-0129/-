﻿using System;


namespace SimpleEvent
{
    public class BridgeGroom
    {
        public delegate void MarryHandler(string msg);
        public event MarryHandler Marryevent;
        public void Sendmsg(string msg)
        {
            if(Marryevent != null)
            {
                Marryevent(msg);
            }
        }
    }
    public class Friends
    {
        public string name;
        public Friends(string _name)
        {
            name = _name;
        
        }
        public void Recievmsg(string msg)
        {
            Console.WriteLine(msg);
            Console.WriteLine(this.name + "收到了我会来的");
        }
    }
    class Mainclass
    {
        public static void Main(string[] args)
        {
            BridgeGroom groom = new BridgeGroom();
            Friends f1 = new Friends("1111");
            Friends f2 = new Friends("2222");
            groom.Marryevent += new BridgeGroom.MarryHandler(f1.Recievmsg);
            groom.Marryevent += new BridgeGroom.MarryHandler(f1.Recievmsg);
            groom.Sendmsg("sssssss");
        }
    }
       
}