﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 枚举例子2
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student() { ID = 101, Name = "Jenkins" };
            Student student2 = student1;
            student2.ID = 202;
            student2.Name = "Timothy";
            Console.WriteLine(student2.Name);
            Console.WriteLine(student1.Name);
            student1.Speak();
            student2.Speak();

            PP2 pP2 = new PP2(554);
            Console.WriteLine(pP2.dys);
        }
    }
    interface ISpeak
    {
        void Speak();
    }
    struct Student : ISpeak
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public void Speak()
        {
            Console.WriteLine($"I'am #{this.ID} student {this.Name}");
        }
    }
    //struct SuperStudent : Student
    //{
    //    /// 结构体不能从其他的结构体派生。
    //}
    //struct PP
    //{
    //    public PP()
    //    {
    //        Console.WriteLine("PP ready");
    //    }
    //    /// 结构体不能生成一个不带参数的构造器。
    //}
    struct PP2
    {
        public int dys;
        public PP2(int dsf)
        {
            this.dys = dsf;
        }
        /// 结构体允许显示的有参构造器。
    }
}
