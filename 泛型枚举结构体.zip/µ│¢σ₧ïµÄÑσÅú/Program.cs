﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student()
            {

                Name = "Jenkins",
                ID = 799265226
            };
            Console.WriteLine(student.Name);
            Console.WriteLine(student.ID);
        }
        interface Iunique<TID>
        {
            TID ID { get; set; }
        }
        class Student : Iunique<ulong>
        {
            public ulong ID { get; set; }
            public String Name { get; set; }

        }
    }
}
