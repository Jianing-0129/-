﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 泛型字典
{
    class Program
    {
        static void Main(string[] args)
        {
            IDictionary<int, string> dict = new Dictionary<int, string>();
            dict[1] = "Tom";
            dict[2] = "Jack";
            Console.WriteLine(dict[1]);
            Console.WriteLine(dict[2]);

        }
    }
}
