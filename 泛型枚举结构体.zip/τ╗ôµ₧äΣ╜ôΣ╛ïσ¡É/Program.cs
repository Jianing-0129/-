﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 结构体例子
{
    class Program
    {
        static void Main(string[] args)
        {
            Student stu = new Student() { ID = 324, Name = "Timothy", };
            object obj = stu;/// 装箱
            Student student2 = (Student)obj;/// 拆箱
            Console.WriteLine(student2.ID);
            Console.WriteLine(student2.Name);
        }
    }
    struct Student
    {
        public int ID { get; set; }
        public string Name { get; set; }

    }
}
