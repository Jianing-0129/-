﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// 枚举可以约束参数的类型（相比属性之下）
/// </summary>
namespace Emurables_and_Struct
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Level = Level.Bigboss;
            Person boss = new Person();
            boss.Level = Level.Boss;
            Console.WriteLine(boss.Level > person.Level);
            ///
            Person Timothy = new Person(); 
            Timothy.Skill = Skill.Cook | Skill.Dirve | Skill.Program | Skill.Teach;
            Console.WriteLine(Timothy.Skill);
            Console.WriteLine((Timothy.Skill&Skill.Cook)==Skill.Cook);
            
        }
    }
    enum Level
    {
        Employee,
        Manager,
        Boss,
        Bigboss,
    }
    enum Skill
    {
        Dirve=1,
        Cook=2,
        Program=4,
        Teach=8,
    }
    class Person
    {
        public Level Level { get; set; }
        public Skill Skill { get; set; }

    }
}
